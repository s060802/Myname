# VERSTREAM — Fullstack Starter (ZIP)

This archive contains a working fullstack starter for VERSTREAM:
- backend/ — Express server with challenge-response login (Ed25519), local uploads, optional S3 presign
- frontend/ — Vite + React minimal UI (register/login/feed)
- Dockerfiles and docker-compose.yml to run locally
- GitHub Actions workflow to build frontend/backend

## Quickstart (local, using Docker Compose)

1. Copy to your host.
2. Create a `.env` file for backend if you want to enable S3:
   - AWS_S3_BUCKET, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION
3. Run:
   ```
   docker-compose up --build
   ```
4. Frontend: http://localhost:5173
   Backend API: http://localhost:4000/api

## Challenge-response login flow

1. POST /api/login-challenge { email } -> { challenge }
2. Client signs challenge with Ed25519 secret key (tweetnacl) and sends signatureHex to:
   POST /api/login-verify { email, signatureHex }
3. Server verifies and returns JWT token.

## Notes
- This project is a demonstration/starter. For production: use real DB (Postgres), secure key handling, HTTPS, CSP, rate limiting, input validation, file scanning, and proper S3 configuration.
