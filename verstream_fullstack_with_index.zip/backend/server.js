const express = require('express');
const http = require('http');
const cors = require('cors');
const bodyParser = require('body-parser');
const multer = require('multer');
const jwt = require('jsonwebtoken');
const nacl = require('tweetnacl');
const fs = require('fs');
const path = require('path');
const { nanoid } = require('nanoid');

const { Low } = require('lowdb');
const { JSONFile } = require('lowdb/node');

const AWS = require('aws-sdk');

const SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';
const PORT = process.env.PORT || 4000;

const app = express();
const server = http.createServer(app);
const io = require('socket.io')(server, { cors: { origin: '*' } });

app.use(cors());
app.use(bodyParser.json());

const dbFile = path.join(__dirname, 'db.json');
const adapter = new JSONFile(dbFile);
const db = new Low(adapter);

(async ()=>{ await db.read(); db.data ||= { users: [], posts: [], messages: [], challenges: {} }; await db.write(); })();

const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

const storage = multer.diskStorage({
  destination: (req,file,cb)=> cb(null, uploadDir),
  filename: (req,file,cb)=> cb(null, `${Date.now()}-${nanoid(6)}-${file.originalname}`)
});
const upload = multer({ storage });

// Helpers
function generateKeypair() {
  const kp = nacl.sign.keyPair();
  return {
    publicKey: Buffer.from(kp.publicKey).toString('hex'),
    privateKey: Buffer.from(kp.secretKey).toString('hex')
  };
}

function findUserByEmail(email) {
  return db.data.users.find(u => u.email === email);
}

// Routes
app.post('/api/register', async (req,res)=>{
  const { name, email } = req.body;
  if (!email) return res.status(400).json({ error: 'Email required' });
  await db.read();
  if (findUserByEmail(email)) return res.status(400).json({ error: 'Email taken' });
  const { publicKey, privateKey } = generateKeypair();
  const user = { id: nanoid(), name: name||'User', email, publicKey, createdAt: Date.now() };
  db.data.users.push(user);
  await db.write();
  // Return privateKey ONCE
  return res.json({ user: { id: user.id, name: user.name, email: user.email, publicKey: user.publicKey }, privateKey });
});

// Challenge-response: Request a login challenge (nonce)
app.post('/api/login-challenge', async (req,res)=>{
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'Email required' });
  await db.read();
  const user = findUserByEmail(email);
  if (!user) return res.status(404).json({ error: 'User not found' });
  const challenge = nanoid(24);
  db.data.challenges[user.email] = { challenge, createdAt: Date.now() };
  await db.write();
  return res.json({ challenge });
});

// Verify signature of challenge and issue JWT
app.post('/api/login-verify', async (req,res)=>{
  const { email, signatureHex } = req.body;
  if (!email || !signatureHex) return res.status(400).json({ error: 'email and signatureHex required' });
  await db.read();
  const user = findUserByEmail(email);
  if (!user) return res.status(404).json({ error: 'User not found' });
  const record = db.data.challenges[user.email];
  if (!record) return res.status(400).json({ error: 'No challenge requested' });
  const challenge = record.challenge;
  // verify signature using publicKey
  try {
    const publicKey = Buffer.from(user.publicKey, 'hex');
    const sig = Buffer.from(signatureHex, 'hex');
    const msg = Buffer.from(challenge);
    const verified = nacl.sign.detached.verify(msg, sig, publicKey);
    if (!verified) return res.status(401).json({ error: 'Invalid signature' });
    // success: issue token
    const token = jwt.sign({ userId: user.id }, SECRET, { expiresIn: '7d' });
    // remove used challenge
    delete db.data.challenges[user.email];
    await db.write();
    return res.json({ token, user });
  } catch (e) {
    console.error(e);
    return res.status(400).json({ error: 'Verification error' });
  }
});

// Optional: presigned S3 upload (if AWS env configured)
app.get('/api/s3-presign', async (req,res)=>{
  const BUCKET = process.env.AWS_S3_BUCKET;
  if (!BUCKET) return res.status(400).json({ error: 'S3 not configured' });
  const key = `uploads/${Date.now()}-${nanoid(6)}`;
  const s3 = new AWS.S3({
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    region: process.env.AWS_REGION
  });
  const params = { Bucket: BUCKET, Key: key, Expires: 60*5, ACL: 'public-read' };
  const url = s3.getSignedUrl('putObject', params);
  return res.json({ url, key, publicUrl: `https://${BUCKET}.s3.amazonaws.com/${key}` });
});

// Fallback local upload
app.post('/api/upload', upload.single('file'), async (req,res)=>{
  if (!req.file) return res.status(400).json({ error: 'No file' });
  const url = `/uploads/${req.file.filename}`;
  return res.json({ url });
});

// Posts
app.post('/api/posts', async (req,res)=>{
  const { caption, mediaUrl, authorId, authorName } = req.body;
  await db.read();
  const p = { id: nanoid(), authorId: authorId||'unknown', authorName: authorName||'Unknown', caption: caption||'', mediaUrl: mediaUrl||null, createdAt: Date.now(), likes: 0 };
  db.data.posts.unshift(p);
  await db.write();
  return res.json({ post: p });
});

app.get('/api/posts', async (req,res)=>{ await db.read(); res.json({ posts: db.data.posts }); });

app.get('/api/users', async (req,res)=>{ await db.read(); res.json({ users: db.data.users }); });

// Simple messages via Socket.IO
io.on('connection', socket => {
  console.log('socket connected');
  socket.on('dm:send', async ({ from, to, text }) => {
    await db.read();
    const msg = { id: nanoid(), from, to, text, createdAt: Date.now() };
    db.data.messages.push(msg);
    await db.write();
    // emit to all clients
    io.emit('dm:receive', msg);
  });
});

app.use('/uploads', express.static(uploadDir));

server.listen(PORT, ()=> console.log('VERSTREAM backend listening on', PORT));
