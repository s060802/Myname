VERSTREAM backend (demo)
- Node.js + Express
- Challenge-response login:
  1) POST /api/login-challenge { email } -> returns { challenge }
  2) Client signs challenge with Ed25519 secretKey (tweetnacl) and sends { email, signatureHex } to /api/login-verify
  3) Server verifies signature with stored publicKey and issues JWT token.
- S3 uploads: GET /api/s3-presign (requires AWS env vars)
- Fallback local uploads: POST /api/upload (multipart/form-data)
