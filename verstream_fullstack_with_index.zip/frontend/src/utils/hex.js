export function toHex(buf){ return Array.from(buf).map(b=>b.toString(16).padStart(2,'0')).join(''); }
export function fromHex(hex){ if (hex.length%2) throw new Error('Invalid hex'); const out = new Uint8Array(hex.length/2); for (let i=0;i<out.length;i++) out[i]=parseInt(hex.substr(i*2,2),16); return out; }
