import React, { useState } from 'react';
import nacl from 'tweetnacl';
import { toHex, fromHex } from '../utils/hex';

export default function Login({ onLogin }){
  const [email,setEmail]=useState(''); const [privateKey,setPrivateKey]=useState('');
  async function startLogin(e){ e.preventDefault();
    const base = (import.meta.env.VITE_API_BASE||'http://localhost:4000');
    const chRes = await fetch(base + '/api/login-challenge', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email }) });
    const ch = await chRes.json();
    if (!ch.challenge) return alert(ch.error||'No challenge');
    // sign challenge with secret key provided by user (hex)
    try {
      const sk = fromHex(privateKey);
      const sig = nacl.sign.detached(new TextEncoder().encode(ch.challenge), sk);
      const sigHex = toHex(sig);
      const verify = await fetch(base + '/api/login-verify', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email, signatureHex: sigHex }) });
      const v = await verify.json();
      if (v.token) { localStorage.setItem('ver_token', v.token); onLogin(v.token, v.user); } else alert(v.error||'Login failed');
    } catch(err){ alert('Ошибка подписи — проверьте приватный ключ'); }
  }
  return (<div className="card"><h2>Вход по приватному ключу</h2><form onSubmit={startLogin}><input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} /><textarea placeholder="Приватный ключ (hex)" value={privateKey} onChange={e=>setPrivateKey(e.target.value)}></textarea><button>Войти</button></form></div>);
}
