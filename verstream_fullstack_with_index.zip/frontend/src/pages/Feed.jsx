import React, { useEffect, useState } from 'react';
export default function Feed(){ const [posts,setPosts]=useState([]);
  useEffect(()=>{ fetch((import.meta.env.VITE_API_BASE||'http://localhost:4000') + '/api/posts').then(r=>r.json()).then(j=>setPosts(j.posts)); },[]);
  return (<div className="container"><h1>Лента</h1>{posts.map(p=> <div key={p.id} className="card"><div>{p.authorName}</div><div>{p.caption}</div>{p.mediaUrl && <img src={(import.meta.env.VITE_API_BASE||'http://localhost:4000')+p.mediaUrl} style={{maxWidth:400}}/>}</div>)}</div>);
}
