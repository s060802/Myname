import React, { useState } from 'react';
export default function Register({ onLogin }){
  const [email,setEmail]=useState(''); const [name,setName]=useState('');
  const [privateKey,setPrivateKey]=useState(null);
  async function submit(e){ e.preventDefault();
    const res = await fetch((import.meta.env.VITE_API_BASE||'http://localhost:4000') + '/api/register', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({name,email}) });
    const data = await res.json();
    if (data.privateKey){
      setPrivateKey(data.privateKey);
      alert('Сохраните приватный ключ — он будет показан ниже.');
      // auto get token via challenge flow: request challenge then sign (we can't sign here automatically without user key)
    } else alert(data.error||'Ошибка');
  }
  return (<div className="card"><h2>Регистрация</h2><form onSubmit={submit}><input placeholder="Имя" value={name} onChange={e=>setName(e.target.value)} /><input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} /><button>Зарегистрироваться</button></form>{privateKey && <textarea readOnly value={privateKey} />}</div>);
}
