import React, { useState } from 'react';
import Register from './pages/Register';
import Login from './pages/Login';
import Feed from './pages/Feed';

export default function App(){
  const [token, setToken] = useState(localStorage.getItem('ver_token')||null);
  const [user, setUser] = useState(null);

  function onLogin(token, user){
    localStorage.setItem('ver_token', token);
    setToken(token);
    setUser(user);
  }
  if (!token) return (<div className="container"><h1>VERSTREAM</h1><Register onLogin={onLogin} /><Login onLogin={onLogin} /></div>);
  return (<Feed token={token} user={user} />);
}
